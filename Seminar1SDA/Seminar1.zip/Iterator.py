class Iterator:
    def __init__(self,beg):
        self.val_iterator = 0
        self.beg = beg

    def next(self,*args):
        if self.val_iterator+1 < len(self.beg):
            self.val_iterator += 1
            return self.beg[self.val_iterator]

    def first(self):
        return self.beg[0]

    def valid(self):
        if self.val_iterator >= 0 and self.val_iterator < self.beg.size():
            return True
        raise IndexError("Index out of range")

    def getCurrent(self):
        if self.valid():
            return self.beg[self.val_iterator]



